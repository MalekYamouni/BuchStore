import type {Book}  from "../interface/Book";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

const API_URL = "http://localhost:8080/api";

async function getBooks(): Promise<Book[]> {
  const res = await fetch(`${API_URL}/books`);
  if (!res.ok) throw new Error("Fehler beim Laden der Bücher");
  return res.json();
}

async function addBook(book: Omit<Book, "id">): Promise<Book> {
  const res = await fetch(`${API_URL}/books`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(book),
  });
  if (!res.ok) throw new Error("Fehler beim Hinzufügen");
  return res.json();
}

async function deleteBook(id: number): Promise<void>{
    const res = await fetch(`${API_URL}/books/${id}`, {method:"DELETE"});
    if(!res.ok) throw new Error("Fehler beim Löschen des Buches")
}

export default function useBooks() {
  const qc = useQueryClient();

  const query = useQuery<Book[], Error>({
    queryFn: () => getBooks(),
    queryKey: ["books"],
  });

  const addNewBook = useMutation({
    mutationFn: addBook,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["books"] });
    },
  });

  const deleteBookFrontEnd = useMutation({
    mutationFn: deleteBook,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["books"] });
    },
  });

  return { ...query, addNewBook, deleteBookFrontEnd };
}
