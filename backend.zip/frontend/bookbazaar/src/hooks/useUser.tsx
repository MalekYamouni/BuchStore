import type { User } from "@/interface/User";
import type { UserRegistration } from "@/pages/UserLogin";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

const API_URL = "http://localhost:8080/api";


async function getUsers(): Promise<User[]> {
  const res = await fetch(`${API_URL}/users`);
  if (!res.ok) throw new Error("Fehler beim Laden der Bücher");
  return res.json();
}

async function addUser(user: Omit<UserRegistration, "id">): Promise<User> {
  const res = await fetch(`${API_URL}/addUser`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user),
  });
  if (!res.ok) throw new Error("Fehler beim Registrieren");
  return res.json();
}

export default function useUsers() {
  const qc = useQueryClient();

  const query = useQuery<User[], Error>({
    queryFn: () => getUsers(),
    queryKey: ["users"],
  });

  const addNewUser = useMutation({
    mutationFn: addUser,
    onSuccess: () => {
      qc.invalidateQueries({queryKey: ["users"]})
    }
  })

  
  return { ...query, addNewUser };
}

