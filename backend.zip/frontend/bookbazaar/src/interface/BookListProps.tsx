import type { Book } from "./BookCardProps";

export interface BookListProps {
}
