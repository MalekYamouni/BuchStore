export interface User{
 Id: number
 name: string
 lastname: string
 username: string
 email:string
 created: string
 password: string
}
