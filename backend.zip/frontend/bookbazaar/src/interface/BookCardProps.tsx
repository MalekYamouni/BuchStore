import type { Book } from "./Book";

export interface BookCardProps {
  book: Book;
  isFavorite: boolean;
  showDeleteButton: boolean;
  showCartButton: boolean;
}
