export interface Book { 
  id: number;
  author: string;  
  name: string;
  price: number;
  quantity?:number
}
