import { Link, useLocation } from "react-router-dom";
import "../styles/NavBar.css";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
} from "@radix-ui/react-navigation-menu";

function NavBar() {
  const location = useLocation();
  return (
    <NavigationMenu >
      <NavigationMenuItem className="flex gap-50 p-5 text-lg font-semibold">
           <NavigationMenuLink asChild>
          <Link className={location.pathname === "/users" ? "active" : ""} to="/users">
            Login
          </Link>
        </NavigationMenuLink>
        <NavigationMenuLink asChild>
          <Link className={location.pathname === "/home" ? "active" : ""} to="/home">
            Home
          </Link>
        </NavigationMenuLink>
        <NavigationMenuLink asChild>
          <Link
            className={location.pathname === "/favorites" ? "active" : ""}
            to="/favorites"
          >
            Favoriten
          </Link>
        </NavigationMenuLink>
        <NavigationMenuLink asChild>
          <Link
            className={location.pathname === "/add" ? "active" : ""}
            to="/add"
          >
            Erstellen
          </Link>
        </NavigationMenuLink>
        <NavigationMenuLink asChild>
          <Link
            className={location.pathname === "/cart" ? "active" : ""}
            to="/cart"
          >
            Warenkorb
          </Link>
        </NavigationMenuLink>
      </NavigationMenuItem>
    </NavigationMenu>
  );
}

export default NavBar;
