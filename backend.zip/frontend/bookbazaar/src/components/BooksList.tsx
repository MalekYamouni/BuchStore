import BookCard from "./BookCard";
import { Label } from "./ui/label";
import { LibraryBig } from "lucide-react";
import { useFavoritesStore } from "@/hooks/useFavorite";
import useBooks from "@/hooks/useApi";


function BookList() {

  const {favorites} = useFavoritesStore(); 
  const {data: books} = useBooks();
  return (
    <div className="flex flex-col gap-5">
      <Label className="text-5xl m-5 flex items-center gap-3"><LibraryBig size={36}></LibraryBig>Bücherliste</Label>
      {books?.map((book) => (
        <BookCard
          key={book.id}
          book={book}
          isFavorite={favorites.some((fav) => fav.id === book.id)}
          showDeleteButton={true}
          showCartButton={true}
        />
      ))}
    </div> 
  );
}

export default BookList;
