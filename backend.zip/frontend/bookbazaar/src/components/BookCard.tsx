import useBooks from "@/hooks/useApi";
import "../styles/Book.css";
import type { BookCardProps } from "../interface/BookCardProps";

import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { useCartStore } from "@/hooks/useCart";
import { HeartMinus, HeartPlus, ShoppingBasket, Trash2 } from "lucide-react";
import { useFavoritesStore } from "@/hooks/useFavorite";

function BookCard({
  book,
  isFavorite,
  showDeleteButton,
  showCartButton,
}: BookCardProps) {
  const { deleteBookFrontEnd } = useBooks();
  const { addToCart } = useCartStore();
  const { addToFavorite } = useFavoritesStore();

  return (
    <Card
      className="w-120 h-50 ml-5 display-flex justify-center
     shadow-lg rounded-2xl hover:scale-105 transition-transform duration-300 gap-5"
    >
      <CardHeader>
        <CardTitle className="text-lg fron-semibold leading-none tracking-tight">
          {book.name}
        </CardTitle>
      </CardHeader>
      <CardContent>{book.author}</CardContent>
      <CardContent>
        {book.price !== undefined ? book.price.toFixed(2) : "Preis unbekannt"} €
      </CardContent>
      <CardFooter className="flex justify-start gap-3">
        <Button
          onClick={() => addToFavorite(book)}
          className="bg-gray-200 hover:bg-pink-600 rounded-full px-3 py-2 text-lg transition-transform duration-200 hover:scale-110 "
          variant={"secondary"}
        >
          {isFavorite ? <HeartMinus></HeartMinus> : <HeartPlus></HeartPlus>}
        </Button>
        {showCartButton && (
          <Button
            onClick={() => addToCart(book)}
            className="bg-gray-200 hover:bg-green-600 text-black rounded-full px-3 py-2 text-lg  transition-transform duration-200 hover:scale-110 "
          >
            <ShoppingBasket></ShoppingBasket>
          </Button>
        )}
        {showDeleteButton && deleteBookFrontEnd && (
          <Button
            onClick={() => {
              console.log("Book, das gelöscht werden soll:", book);
              deleteBookFrontEnd.mutate(book.id);
            }}
            className="bg-gray-200 hover:bg-red-600 text-black rounded-full px-3 py-2 text-lg  transition-transform duration-200 hover:scale-110 "
            variant={"destructive"}
          >
            <Trash2></Trash2>
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}

export default BookCard;

// </div>
