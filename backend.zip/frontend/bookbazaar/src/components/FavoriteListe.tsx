import { Label } from "@radix-ui/react-label";
import BookCard from "./BookCard";
import { BookHeart } from "lucide-react";
import { useFavoritesStore } from "@/hooks/useFavorite";

function FavoriteList() {
  const { favorites } = useFavoritesStore();
  return (
    <div>
      <Label className="text-5xl m-5 flex items-center gap-3">
        <BookHeart size={36}></BookHeart>Favoriten
      </Label>

      {favorites.length === 0 ? (
        <Label className="text-2xl m-5 flex items-center gap-3">
          Keine Favoriten hinzugefügt
        </Label>
      ) : (
        favorites.map((book) => (
          <BookCard
            key={book.id}
            book={book}
            isFavorite={true}
            showDeleteButton={false}
            showCartButton={true}
          />
        ))
      )}
    </div>
  );
}
export default FavoriteList;
