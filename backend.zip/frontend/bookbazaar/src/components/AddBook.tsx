import { use, useState } from "react";
import "../styles/AddBook.css";
import useBooks from "@/hooks/useApi";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

function AddBook() {
  const [form, setForm] = useState({ name: "", author: "", price: "" });
  const { addNewBook } = useBooks();

  // Das ist für die Input-Felder
  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  // Das ist für den Submit-Button
  function handleSubmit(e: React.ChangeEvent<HTMLFormElement>) {
    e.preventDefault();

    const { name, author, price } = form;

    if (!name || !author || !price) {
      alert("Bitte alle Felder ausfüllen");
      return;
    }

    const priceNumber = parseFloat(form.price);
    if (isNaN(priceNumber) || priceNumber <= 0) {
      alert("Bitte geben Sie einen gültigen Preis ein");
      setForm((prev) => ({ ...prev, price: "" }));
      return;
    }

    addNewBook.mutate({
      name: name,
      author: author,
      price: priceNumber,
    });

    setForm({ name: "", author: "", price: "" });
  }

  return (
    <div className="bg-[#333] flex flex-col items-center justify-items-start min-h-screen ">
      <form
        className="bg-gray-200 p-6 rounded-xl shadow-lg flex flex-col gap-4 w-full max-w-md brd mt-50"
        onSubmit={handleSubmit}
      >
        <Input
          name="name"
          type="text"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          className="border border-gray-500"
        />
        <Input
          name="author"
          type="text"
          placeholder="Autor"
          value={form.author}
          onChange={handleChange}
          className="border border-gray-500"
        />
        <Input
          name="price"
          placeholder="Preis"
          type="number"
          value={form.price ?? ""}
          onChange={handleChange}
          className="border border-gray-500"
        />
        <Button type="submit">Buch hinzufügen 📘</Button>
      </form>
    </div>
  );
}
export default AddBook;
