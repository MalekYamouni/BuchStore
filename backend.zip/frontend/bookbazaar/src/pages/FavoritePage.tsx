import FavoriteList from "../components/FavoriteListe";


function FavoritePage() {
  return (
    <div>
      <FavoriteList />
    </div>
  );
}

export default FavoritePage;
