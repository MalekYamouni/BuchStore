import { useMemo } from "react";
import ShoppingCartCard from "../components/ShoppingCartCard";
import "../styles/totalPrice.css";
import { useCartStore } from "@/hooks/useCart";
import { Label } from "@radix-ui/react-label";
import { ShoppingBasket } from "lucide-react";

function ShoppingCart() {
  const { shoppingCart } = useCartStore();

  const totalPrice = useMemo(
    () =>
      shoppingCart.reduce(
        (sum, book) => (sum += book.price * (book.quantity ?? 1)),
        0
      ),
    [shoppingCart]
  );

  return (
    <div>
      <Label className="text-5xl m-5 flex items-center gap-3">
        <ShoppingBasket size={36}></ShoppingBasket>Warenkorb
      </Label>{" "}
      <div className="flex flex-col gap-5 justify-start m-4">
        {shoppingCart.length === 0 ? (
          <p>Dein Warenkorb ist leer.</p>
        ) : (
          shoppingCart.map((book) => (
            <ShoppingCartCard key={book.id} book={book} />
          ))
        )}
      </div>
      <div className="total-price">
        {totalPrice === 0 ? (
          <h2>Stöbern Sie hier</h2>
        ) : (
          <h2>Gesamtpreis {totalPrice.toFixed(2)}€</h2>
        )}
      </div>
    </div>
  );
}

export default ShoppingCart;
