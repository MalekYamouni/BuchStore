import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuthStore } from "@/hooks/userAuth";
import useUsers from "@/hooks/useUser";
import { useState } from "react";
import { useForm } from "react-hook-form";

type FormData = {
  name: string;
  lastname: string;
  username: string;
  email: string;
  password: string;
};

export interface UserRegistration {
   name: string
  lastname: string
  username: string
  email: string
  password: string
}

function UserLogin() {
  const { data: users, isLoading, error, addNewUser } = useUsers();
  const [showRegister, setShowRegister] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>();

  const onSubmit = (data: FormData) => {
    const newUser: UserRegistration = {
    name: data.name,
    lastname: data.lastname,
    username: data.username,
    email: data.email,
    password: data.password
  }

    console.log(JSON.stringify(newUser, null, 2))
    addNewUser.mutate(newUser);
  };
  const [userName, setUsername] = useState("");
  const [passWord, setPassword] = useState("");
  const { login } = useAuthStore();

  function handleLogin() {
    const user = users?.find((username) => username.username === userName);
    const password = users?.find((pw) => pw.password === passWord);

    if (!user) {
      console.log("Keinen User mit diesem Usernamen gefunden");
      setUsername("");
      return;
    }

    if (!password) {
      console.log("Falsches Passwort");
      setPassword("");
      return;
    }
    login();
  }

  if (isLoading) return <p>Lade Benutzer</p>;
  if (error) return <p>Fehler: {error.message}</p>;

  if (showRegister) {
    return (
      <Card
        className="w-120 h-100 ml-5 display-flex justify-center
     shadow-lg rounded-2xl hover:scale-105 transition-transform duration-300 gap-5"
      >
        <CardHeader>
          <CardTitle className="text-lg fron-semibold leading-none tracking-tight">
            Registrieren
          </CardTitle>
        </CardHeader>
        <form onSubmit={handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            <div>
              <Input
                {...register("name", {
                  required: "Vorname ist Pflicht",
                })}
                placeholder="Vorname"
                type="text"
              ></Input>
              {errors.name && (
                <p className="text-red-500 text-sm">{errors.name.message}</p>
              )}
              <Input
                {...register("lastname", {
                  required: "Nachname ist Pflicht",
                })}
                type="text"
                placeholder="Nachname"
              ></Input>
              <Input
                {...register("email", {
                  required: "E-Mail ist Pflicht",
                  pattern: {
                    value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                    message: "Ungültige E-Mail",
                  },
                })}
                type="email"
                placeholder="Email"
              ></Input>
              <Input {...register("username", {
                required: "Username ist Pflicht"
              })}  type="text" placeholder="Username"></Input>
              <Input {...register("password", {
                required: "Passwort ist Pflicht", minLength:{value:6, message:"Mindestens 6 Zeichen"}
              })} type="password" placeholder="Passwort"></Input>
            </div>
          </CardContent>
          <CardFooter className="flex justify-start gap-3">
            <Button type="submit">Registrieren</Button>
            <Button onClick={() => setShowRegister(false)}>Zurück</Button>
          </CardFooter>
        </form>
      </Card>
    );
  }

  return (
    <Card
      className="w-120 h-50 ml-5 display-flex justify-center
     shadow-lg rounded-2xl hover:scale-105 transition-transform duration-300 gap-5"
    >
      <CardHeader>
        <CardTitle className="text-lg fron-semibold leading-none tracking-tight">
          Anmeldung
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Input
          placeholder="Username"
          value={userName}
          onChange={(e) => setUsername(e.target.value)}
        ></Input>
        <Input
          placeholder="Passwort"
          value={passWord}
          type="password"
          onChange={(e) => setPassword(e.target.value)}
        ></Input>
      </CardContent>
      <CardFooter className="flex justify-start gap-3">
        <Button onClick={handleLogin}>Anmelden</Button>
        <Button onClick={() => setShowRegister(true)}>Registrieren</Button>
      </CardFooter>
    </Card>
  );
}

export default UserLogin;
