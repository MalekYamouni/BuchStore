import AddBook from "../components/AddBook";

function AddBookPage() {

  return (
    <div>
      <AddBook/>
    </div>
  );
}

export default AddBookPage;
