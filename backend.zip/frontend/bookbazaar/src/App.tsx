import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import NavBar from "./components/Navbar";
import HomePage from "./pages/HomePage";
import ShoppingCart from "./pages/ShoppingCart";
import FavoritePage from "./pages/FavoritePage";
import AddBookPage from "./pages/AddBookPage";
import UserLogin from "./pages/UserLogin";

function App() {
  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="/home" element={<HomePage />} />
        <Route path="/add" element={<AddBookPage />} />
        <Route path="/favorites" element={<FavoritePage />} />
        <Route path="/cart" element={<ShoppingCart />} />
        <Route path="/users" element={<UserLogin />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
