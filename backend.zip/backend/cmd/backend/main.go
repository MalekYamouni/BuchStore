package main

import (
	"bookbazaar-backend/internal/app"
)

func main() {
	app.Run()
}
