package app

import (
	"bookbazaar-backend/internal/handlers"
	"bookbazaar-backend/internal/repository"
	"bookbazaar-backend/internal/services"
	"database/sql"
	"log"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	_ "github.com/jackc/pgx/v5/stdlib"
)

func Run() {
	db, err := sql.Open("pgx", "postgresql://postgres:Gurkenwasser451995!.@localhost:5432/bookbazaar?sslmode=disable")

	if err != nil {
		log.Fatal("Fehler beim Verbinden mit der Datenbank:", err)
	}

	if err := db.Ping(); err != nil {
		log.Fatal("Datenbank ist nicht erreichbar:", err)
	}

	r := gin.Default()

	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"http://localhost:5173"}, // nur deine React-App
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE"},
		AllowHeaders:     []string{"Origin", "Content-Type"},
		ExposeHeaders:    []string{"Content-Length"},
		AllowCredentials: true,
		MaxAge:           12 * time.Hour,
	}))

	log.Println("in der app")
	bookRepo := repository.NewBookRepository(db)
	bookService := services.NewBookService(bookRepo)
	bookController := handlers.NewBookController(bookService)

	userRepo := repository.NewUserRepository(db)
	userService := services.NewUserService(userRepo)
	userController := handlers.NewUserController(userService)

	api := r.Group("/api")
	{
		api.GET("/books", bookController.GetBooks)
		api.GET("/users", userController.GetUsers)
		api.POST("/addUser", userController.AddUser)
		api.POST("/books", bookController.AddBooks)
		api.DELETE("/books/:id", bookController.DeleteBooks)
	}

	if err := r.Run(); err != nil {
		log.Fatal("Fehler beim Starten des Servers:", err)
	}
}
