package repository

import (
	"bookbazaar-backend/internal/models"
	"database/sql"
	"fmt"
	"log"
)

type BookRepository struct {
	db *sql.DB
}

func NewBookRepository(db *sql.DB) *BookRepository {
	return &BookRepository{db: db}
}

func (r *BookRepository) GetAll() ([]models.Book, error) {
	rows, err := r.db.Query("SELECT id, author,name, price FROM books")
	if err != nil {
		log.Println("Fehler bei Query:", err)
		return nil, err
	}
	defer rows.Close()
	var books []models.Book
	for rows.Next() {
		var book models.Book
		if err := rows.Scan(&book.ID, &book.Author, &book.Name, &book.Price); err != nil {
			log.Println("Fehler beim Scan:", err)
			return nil, err
		}
		books = append(books, book)
	}

	return books, nil
}

// Buch hinzufügen
func (r *BookRepository) Add(book *models.Book) error {

	query := `INSERT INTO books (author, name, price) VALUES ($1, $2, $3) RETURNING id`

	err := r.db.QueryRow(query, book.Author, book.Name, book.Price).Scan(&book.ID)

	if err != nil {
		log.Println("Fehler beim Insert", err)
		return err
	}
	log.Println("Neues Buch ID:", book.ID)
	return nil
}

// Buch löschen
func (r *BookRepository) Delete(id int) error {

	query := `DELETE FROM books WHERE id=$1`

	result, err := r.db.Exec(query, id)

	if err != nil {
		log.Println("Fehler beim Delete", err)
		return err
	}

	rowsAffected, err := result.RowsAffected()

	if err != nil {
		return err
	}

	if rowsAffected == 0 {
		log.Println("Kein Buch gefunden mit ID: ", id)
		return fmt.Errorf("kein Buch mit ID %d gefunden", id)
	}

	log.Println("Buch erfolgreich gelöscht mit ID:", id)

	return nil
}
