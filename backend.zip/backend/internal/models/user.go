package models

import "time"

type User struct {
	ID       int       `json:"id"`
	Name     string    `json:"name"`
	Lastname string    `json:"lastname"`
	Username string    `json:"username"`
	Created  time.Time `json:"created"`
	Email    string    `json:"email"`
	Password string    `json:"password"`
}
