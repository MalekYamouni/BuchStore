package models

type Book struct {
	ID     int     `json:"id"`
	Author string  `json:"author"`
	Name   string  `json:"name"`
	Price  float64 `json:"price"`
}
