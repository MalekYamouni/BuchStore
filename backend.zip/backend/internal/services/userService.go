package services

import (
	"bookbazaar-backend/internal/models"
	"bookbazaar-backend/internal/repository"
	"errors"
	"log"
	"net/mail"
)

type UserService interface {
	GetAllUsers() ([]models.User, error)
	AddUser(user *models.User) (*models.User, error)
}

type DefaultUserService struct {
	repo *repository.UserRepository
}

func NewUserService(r *repository.UserRepository) UserService {
	return &DefaultUserService{repo: r}
}

func (s *DefaultUserService) GetAllUsers() ([]models.User, error) {
	log.Println("Service.GetAllUsers wurde aufgerufen")
	return s.repo.GetAllUsers()
}

func isValidEmail(email string) bool {
	_, err := mail.ParseAddress(email)
	return err == nil
}

func (s *DefaultUserService) AddUser(user *models.User) (*models.User, error) {
	log.Println("Service.AddUser wurde aufgerufen")

	if len(user.Name) <= 3 || len(user.Lastname) <= 3 || len(user.Username) <= 3 {
		return nil, errors.New("name muss länger sein als 3 Zeichen sein")
	}

	if valid := (isValidEmail(user.Email)); !valid {
		return nil, errors.New("email ist nicht gültig")
	}

	if err := s.repo.AddUser(user); err != nil {
		return nil, err
	}

	log.Println(user)
	return user, nil
}
