package services

import (
	"bookbazaar-backend/internal/models"
	"bookbazaar-backend/internal/repository"
	"fmt"
)

type BookService interface {
	GetAll() ([]models.Book, error)
	Create(book *models.Book) (*models.Book, error)
	Delete(id int) error
}

type DefaultBookService struct {
	repo *repository.BookRepository
}

func NewBookService(r *repository.BookRepository) BookService {
	return &DefaultBookService{repo: r}
}

func (s *DefaultBookService) GetAll() ([]models.Book, error) {
	return s.repo.GetAll()
}

// Buch hinzufügen
func (s *DefaultBookService) Create(book *models.Book) (*models.Book, error) {

	// backend Validierung
	if book.Name == "" {
		return nil, fmt.Errorf("buchname darf nicht leer sein")
	}

	if err := s.repo.Add(book); err != nil {
		return nil, err
	}
	return book, nil
}

// Buch löschen
func (s *DefaultBookService) Delete(id int) error {
	return s.repo.Delete(id)
}
